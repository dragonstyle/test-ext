return {
    {
      Strong = function (elem)
        return pandoc.SmallCaps(elem.c)
      end,
    }
  }